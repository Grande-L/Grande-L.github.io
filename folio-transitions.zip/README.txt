A Pen created at CodePen.io. You can find this one at https://codepen.io/foliodot/pen/MKNeKB.

 Out of the box page & section transitions with Foliodot (https://foliodot.com/) website starter template. 

All images in this pen:  https://unsplash.com/